// -*- C++ -*-

//=============================================================================
/**
 * @file    LogMessage_Worker_Impl.h
 *
 * $Id: LogMessage_Worker.h 3467 2013-10-01 11:00:00Z marianne.rieckmann $
 *
 * This file contains the log worker implementation. This worker has
 * been developed using the default memory worker code as a template.
 *
 * @author            Marianne Rieckmann <marianne.rieckmann@adelaide.edu.au>
 */
//=============================================================================

#ifndef _DIG_LOGMESSAGE_WORKER_IMPL_H_
#define _DIG_LOGMESSAGE_WORKER_IMPL_H_

#include <ndds/ndds_cpp.h>
#include "LogMessageDDSSupport.h"
#include "Effector_Worker_T.h"
#include "ace/High_Res_Timer.h"
#include "ace/OS_NS_string.h"
#include "ace/OS_NS_sys_time.h"
#include "ace/OS_NS_unistd.h"
#include "ace/Guard_T.h"

/**
 * @class DIG_LogMessage_Worker_Impl
 *
 * Workload generator for LogMessage operations
 */
class DIG_LogMessage_Worker_Impl 
{
public:
  /// Type definition for the TypeSupport type
  typedef ::DIGLogMessageTypeSupport typesupport_Type;

  /// Type definition for the DataWriter type
  typedef ::DIGLogMessageDataWriter datawriter_Type;
  
  /// Type definition for the log data type
  typedef ::DIGLogMessage logdata_Type;

  /// Default Constructor.
  DIG_LogMessage_Worker_Impl (void);

  /// Destructor.
  virtual ~DIG_LogMessage_Worker_Impl (void);

  /* Connect to Synthetic environment, 
   * @param[in]       inst_name        Component Instance Name.
   * @param[in]       domain_id        Domain ID for DIGLogger, defaults to 9
   * @param[in]       topic_name       Topic name for publishing log data 
   */
  int connect (const char * inst_name, const int domain_id, const char * topic_name);

  /// Disconnect from Sythetic environment
  int disconnect (void);
  
  /// Switch Topic for Synthetic environment, 
  int switch_topic (const char * topic_name);

  /// Send available data 
  virtual int send_data (logdata_Type * data);

  // Log message given message string, will assume severity of LM_DEBUG 
  int log (const char * message, int severity);

private:
  /// Effector worker
  DIG_Effector_Worker_T < ::DIGLogMessageTypeSupport, ::DIGLogMessageDataWriter, ::DIGLogMessage > effector_;
  std::string inst_name_;
};

#endif  // !defined _DIG_LOGMESSAGE_WORKER_IMPL_H_
