// -*- C++ -*-

//=============================================================================
/**
 * @file    Effector_Worker_T.h
 *
 * $Id: Effector_Worker_T.h 3467 2012-12-21 11:00:00Z marianne.rieckmann $
 *
 * This file contains the effector worker generic implementation.
 *
 * @author Marianne Rieckmann <marianne.rieckmann@adelaide.edu.au>
 */
//=============================================================================

#ifndef _DIG_EFFECTOR_WORKER_T_H_
#define _DIG_EFFECTOR_WORKER_T_H_

#include "cuts/Worker.h"
#include <ndds/ndds_cpp.h>
#include <iostream>

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif  // ACE_LACKS_PRAGMA_ONCE

/**
 * @class DIG_Effector_Worker_T
 *
 * Workload generator for Effector operations
 */
template <typename TYPESUPPORT, typename DATAWRITER, typename TYPE>
class DIG_Effector_Worker_T : 
  public CUTS_Worker
{
public:
  /// Type definition for the TypeSupport type
  typedef TYPESUPPORT typesupport_Type;

  /// Type definition for the DataWriter type
  typedef DATAWRITER datawriter_Type;
  
  /// Type definition for the effector data type
  typedef TYPE effectordata_Type;
  
  /// Constructor.
  DIG_Effector_Worker_T (void);

  /// Destructor.
  virtual ~DIG_Effector_Worker_T (void);

  /* Connect to Synthetic environment, 
   * @param[in]       domain_id        Domain ID for DIGLogger, defaults to 9
   * @param[in]       topic_name       Topic name information for publishing effector data DDS.
   */
  int connect (const int domain_id, const char * topic_name);

  /// Disconnect from Sythetic environment
  int disconnect (void);

  // Switch Topic for Synthetic environment, 
  int switch_topic (const char * topic_name);
  bool is_source(void);
  const char * get_type_name(void);
  const char * get_topic_name(void);

  /// send available data 
  virtual int send_data (effectordata_Type * data);

  /// place holder for data_distributor properties, this function should not get called.
  //virtual void handle_data_distributor (void);

private:
  /// DDS subscriber variables
  DDSDomainParticipant *        participant_;
  DDSTopic *                    topic_;
  datawriter_Type *             custom_data_writer_;
  int                           domain_id_;
  std::string                   topic_name_;

};

#include "Effector_Worker_T.cpp"

#endif  // !defined _DIG_EFFECTOR_WORKER_T_H_
