// -*- C++ -*-

//=============================================================================
/**
 * @file    LogMessage_Worker.h
 *
 * $Id: LogMessage_Worker.h 3467 2013-10-01 11:00:00Z marianne.rieckmann $
 *
 * @author Marianne Rieckmann <marianne.rieckmann@adelaide.edu.au>
 */
//=============================================================================

#ifndef _DIG_LOGMESSAGE_WORKER_H_
#define _DIG_LOGMESSAGE_WORKER_H_

#include "LogMessage_Worker_export.h"
#include "cuts/Worker.h"

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif  // ACE_LACKS_PRAGMA_ONCE

/// forward declaration
class DIG_LogMessage_Worker_Impl;   

/**
 * @class DIG_LogMessage_Worker
 *
 * Workload generator for LogMessage operations
 */
class DIG_LOGMESSAGE_WORKER_Export DIG_LogMessage_Worker : 
  public CUTS_Worker
{
public:
  /// Constructor.
  DIG_LogMessage_Worker (void);

  /// Destructor.
  virtual ~DIG_LogMessage_Worker (void);

  /* Connect to Logger domain, 
   * @param[in]       inst_name        Component Instance Name.
   * @param[in]       domain_id        Domain ID for DIGLogger, defaults to 9
   * @param[in]       topic_name       Topic name for publishing log data 
   */
  int connect (const char * inst_name, const int domain_id, const char * topic_name);

  /// Disconnect from Sythetic environment
  int disconnect (void);

  // Switch Topic for Synthetic environment, 
  int switch_topic (const char * topic_name);

  /// get available data from list and remove
  //virtual int send_data (logdata_Type * data);

  // Log message given message string, will assume severity of LM_DEBUG 
  int log (const char * message, int severity);

private:
  /// pointer to implementation.
  std::auto_ptr <DIG_LogMessage_Worker_Impl> impl_;

};

/**
 * @class CUTS_Worker_Traits <CUTS_Memory_Worker>
 */
template <>
class CUTS_Worker_Traits <DIG_LogMessage_Worker>
{
public:
  static const long worker_id_ = 9;
};

#endif  // !defined _DIG_LOGMESSAGE_WORKER_H_
