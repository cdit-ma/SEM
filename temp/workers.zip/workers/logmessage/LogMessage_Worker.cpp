// $Id: LogMessage_Worker.cpp 3467 2012-11-29 11:00:00Z marianne.rieckmann $

#include "LogMessage_Worker.h"
#include "LogMessage_Worker_Impl.h"

//
// DIG_LogMessage_Worker
//
DIG_LogMessage_Worker::DIG_LogMessage_Worker (void)
: impl_ ( new DIG_LogMessage_Worker_Impl() )  
{

}

//
// ~DIG_LogMessage_Worker
//
DIG_LogMessage_Worker::~DIG_LogMessage_Worker (void)
{
}

//
// Connect to Synthetic environment
//
int DIG_LogMessage_Worker::connect (const char * inst_name = "", const int domain_id = 9, const char * topic_name = "DIGLogger")
{
  int err_ret;
  if (strcmp(topic_name, "") == 0) 
     err_ret = this->impl_->connect(inst_name, domain_id, "DIGLogger");
  else
     err_ret = this->impl_->connect(inst_name, domain_id, topic_name);
  return (err_ret);
}

//
// Disconnect from Sythetic environment
//
int DIG_LogMessage_Worker::disconnect (void)
{
  return (this->impl_->disconnect());
}

//
// Switch Topic for Synthetic environment, 
//
int DIG_LogMessage_Worker::switch_topic (const char * topic_name)
{
  return (this->impl_->switch_topic(topic_name));
}

//
// Perform effector send data 
//
//int DIG_LogMessage_Worker::send_data (logdata_Type * data)
//{
//  return (this->impl_->send_data(data));
//}


//
// Switch Topic for Synthetic environment, 
//
int DIG_LogMessage_Worker::log (const char * message, int severity = LM_DEBUG)
{
  return (this->impl_->log(message, severity));
}
