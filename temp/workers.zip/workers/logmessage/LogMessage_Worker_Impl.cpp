// $Id: LogMessage_Worker_Impl.cpp 3467 2012-11-29 11:00:00Z marianne.rieckmann $

#include "LogMessage_Worker_Impl.h"
#include "ace/Log_Msg.h"

//
// DIG_LogMessage_Worker_Impl
//
DIG_LogMessage_Worker_Impl::DIG_LogMessage_Worker_Impl (void)
{
}

//
// ~DIG_LogMessage_Worker_Impl
//
DIG_LogMessage_Worker_Impl::~DIG_LogMessage_Worker_Impl (void)
{
}

//
// Connect to Synthetic environment, 
//
int DIG_LogMessage_Worker_Impl::connect (const char * inst_name = "", const int domain_id = 9, const char * topic_name = "DIGLogger")
{
  this->inst_name_ = inst_name;
  return (this->effector_.connect(domain_id, topic_name));
}

//
// Disconnect from Sythetic environment
//
int DIG_LogMessage_Worker_Impl::disconnect (void)
{
  return (this->effector_.disconnect ());
}

//
// Switch Topic for Synthetic environment, 
//
int DIG_LogMessage_Worker_Impl::switch_topic (const char * topic_name)
{
  return (this->effector_.switch_topic(topic_name));
}

//
// Perform effector send data
//
int DIG_LogMessage_Worker_Impl::send_data (logdata_Type * data)
{
  return (this->effector_.send_data(data));
}

//
// Log message given message string, will assume severity of LM_DEBUG 
//
int DIG_LogMessage_Worker_Impl::log (const char * message, int severity = LM_DEBUG )
{
  // Create and populate effector data message
  logdata_Type * log = typesupport_Type::create_data();

  char hostname[1024];
  ACE_OS::hostname (hostname, sizeof (hostname));
  strcpy(log->hostname, hostname);
  strcpy(log->instName, this->inst_name_.c_str());
  strcpy(log->message, message);
  log->severity = severity;
  log->thread_id = ACE_OS::thr_self ();
  ACE_Time_Value tv = ACE_OS::gettimeofday ();
  log->timestamp_sec = tv.sec ();
  log->timestamp_usec = tv.usec();
  return ( this->effector_.send_data (log) );
}

/*
// Do we want to implement log in same way CUTS Logger Worker did it?
// Log message given severity and formated string 
//
int DIG_LogMessage_Worker_Impl::log (int severity, const char * format, ...)
{
  // Initialize the variable arguments list.
  va_list args;
  va_start (args, format);

  // Parse the format string.
  std::ostringstream ostr;
  CUTS_Format_Parser parser;
  parser.parse (format, args, ostr);

  // End the variable arguments.
  va_end (args);

  // Create and populate effector data message
  ::DDSlog * log = ::DDSlogTypeSupport::create_data();

  char hostname[1024];
  ACE_OS::hostname (hostname, sizeof (hostname));
  strcpy(log->hostname, hostname);
  strcpy(log->instName, this->instName());
  strcpy(log->message, ostr.str().c_str());
  log->severity = severity;
  log->thread_id = ACE_OS::thr_self ();
  ACE_Time_Value tv = ACE_OS::gettimeofday ();
  log->timestamp_sec = tv.sec ();
  log->timestamp_usec = tv.usec();
  return ( this->effector_.send_data (log) );
}
*/


