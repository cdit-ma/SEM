// $Id: Effector_Worker_T.cpp 3467 2012-11-29 11:00:00Z marianne.rieckmann $

#include "Effector_Worker_T.h"
#include "ace/Log_Msg.h"

//
// DIG_Effector_Worker_T
//
template <typename TYPESUPPORT, typename DATAWRITER, typename TYPE>
DIG_Effector_Worker_T <TYPESUPPORT,DATAWRITER,TYPE>::DIG_Effector_Worker_T (void)
{
  this->participant_ = NULL;
  this->topic_ = NULL;
  this->custom_data_writer_ = NULL;
  this->topic_name_ = "";
  
  DDS_DomainParticipantFactoryQos factoryQoS;
  DDSTheParticipantFactory->get_qos(factoryQoS);
  // increase max_objects_per_thread as needed. The default is 1024 (512 for 4.4c and below). 
  factoryQoS.resource_limits.max_objects_per_thread = 4096;
  DDSTheParticipantFactory->set_qos(factoryQoS);
}

//
// ~DIG_Effector_Worker
//
template <typename TYPESUPPORT, typename DATAWRITER, typename TYPE>
DIG_Effector_Worker_T <TYPESUPPORT,DATAWRITER,TYPE>::~DIG_Effector_Worker_T (void)
{
}

//
// Connect to Synthetic environment
//
template <typename TYPESUPPORT, typename DATAWRITER, typename TYPE>
int DIG_Effector_Worker_T <TYPESUPPORT,DATAWRITER,TYPE>::connect (const int domain_id, const char * topic_name)
{
  DDS_ReturnCode_t retcode;
  const char *     type_name = TYPESUPPORT::get_type_name();
  this->domain_id_ = domain_id;
  this->topic_name_ = topic_name;
//  DDSPublisher *   publisher;
  DDSDataWriter *  data_writer;

  ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Effector_Worker_T::connect %s\n"), this->topic_name_.c_str()));

  // Lookup participant for this domain ID, and use that if one exists.
  this->participant_ = DDSDomainParticipantFactory::get_instance()->lookup_participant( this->domain_id_ );  
  if (this->participant_ == NULL) {
	  // Create the domain participant on domain ID default is 9 for logger
	  this->participant_ = DDSDomainParticipantFactory::get_instance()->create_participant(
		this->domain_id_,               // Domain ID
		DDS_PARTICIPANT_QOS_DEFAULT,    // QoS 
		NULL,                           // Listener 
		DDS_STATUS_MASK_NONE);
  }
  if (this->participant_ == NULL) {
    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create domain participant.%s\n"), ""));
  } else {

//    publisher = participant->create_publisher(
//        DDS_PUBLISHER_QOS_DEFAULT, NULL /* listener */, DDS_STATUS_MASK_NONE);
//    if (publisher == NULL) {
//	  ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create publisher with domain participant.%s\n"), ""));
//	} else {

      retcode = TYPESUPPORT::register_type(this->participant_, type_name);
	  if (retcode != DDS_RETCODE_OK) {
	      ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to register type with domain participant.%s\n"), ""));
	  } else {
        // Find topic and use if it already exists for this participant
		struct DDS_Duration_t timeout = {0,1000};  //wait for 1000 nanoseconds 
		this->topic_ = this->participant_->find_topic(
			this->topic_name_.c_str(),             // Topic name
			timeout);
		if (this->topic_ == NULL) {
			// Create the topic "Effector Worker" for the String type 
			this->topic_ = this->participant_->create_topic(
				this->topic_name_.c_str(),             // Topic name
				type_name,                             // Type name 
				DDS_TOPIC_QOS_DEFAULT,                 // Topic QoS 
				NULL,                                  // Listener  
				DDS_STATUS_MASK_NONE);
		}
		if (this->topic_ == NULL) {
			ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create topic.%s\n"), ""));
		} else {


	      // Create the data writer using the implicit publisher for this participant 
		  data_writer = this->participant_->create_datawriter(
			this->topic_,
	        DDS_DATAWRITER_QOS_DEFAULT,    // QoS 
		    NULL,                          // Listener 
			DDS_STATUS_MASK_NONE);
	      if (data_writer == NULL) {
		    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create data writer.%s\n"), ""));
	      } else {

            this->custom_data_writer_ = DATAWRITER::narrow(data_writer);
            if (this->custom_data_writer_ == NULL) {
	          ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create custom data writer.%s\n"), ""));
			} else {
		      return (0); // DDS connection successfull
			}
		  }
		}
      }
  }
  return (-1); 
}

//
// Disconnect from Sythetic environment
//
template <typename TYPESUPPORT, typename DATAWRITER, typename TYPE>
int DIG_Effector_Worker_T <TYPESUPPORT,DATAWRITER,TYPE>::disconnect (void)
{
  DDSDataWriter * data_writer;
  DDS_ReturnCode_t retcode = DDS_RETCODE_OK;

  ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Effector_Worker_T::disconnect %s\n"), ""));
  if (this->participant_ != NULL) {
	// delete entities created by this process, but do not delete participant as it may be shared.
	// All users of participant should do this, and not delete the participant unless all entities have been deleted.
	// To be safe we need to test if this->participant_ still exists...?
    data_writer = this->custom_data_writer_;  
	retcode = this->participant_->delete_datawriter(data_writer);
	if (retcode != DDS_RETCODE_OK) {
	    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Deletion of data writer failed.%s\n"), ""));
    } else { 
		retcode = this->participant_->delete_topic(this->topic_);
		if (retcode != DDS_RETCODE_OK) {
	   		ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Deletion of topic failed.%s\n"), ""));
    	}
	}
  }
  if (retcode == DDS_RETCODE_OK)
    return (0);
  else 
    return (-1);
}

//
// Switch Topic for Synthetic environment, 
//
template <typename TYPESUPPORT, typename DATAWRITER, typename TYPE>
int DIG_Effector_Worker_T <TYPESUPPORT,DATAWRITER,TYPE>::switch_topic (const char * topic_name)
{
  DDS_ReturnCode_t retcode;
  const char *     type_name = TYPESUPPORT::get_type_name();
  this->topic_name_ = topic_name;

  DDSDataWriter *  data_writer;

  ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Effector_Worker_T::switch_topic %s\n"), this->topic_name_.c_str()));

  // Assume and check that the domain participant exists
  if (this->participant_ != NULL) {

    // Delete the previous datawriter and topic from this participant.
    data_writer = this->custom_data_writer_;  // may need to cast this to a DDSDataWriter 
	retcode = this->participant_->delete_datawriter(data_writer);
	if (retcode != DDS_RETCODE_OK) {
	    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Deletion of data writer failed.%s\n"), ""));
    } else { 
		retcode = this->participant_->delete_topic(this->topic_);
		if (retcode != DDS_RETCODE_OK) {
	   		ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Deletion of topic failed.%s\n"), ""));
    	} else { 

		// Create the new topic for Effector Worker 
		this->topic_ = this->participant_->create_topic(
			this->topic_name_.c_str(),             // Topic name
			type_name,                             // Type name 
			DDS_TOPIC_QOS_DEFAULT,                 // Topic QoS 
			NULL,                                  // Listener  
			DDS_STATUS_MASK_NONE);
		if (this->topic_ == NULL) {
			ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create topic.%s\n"), ""));
		} else {

	      // Create the data writer using the implicit publisher for participant
		  data_writer = this->participant_->create_datawriter(
			this->topic_,
	        DDS_DATAWRITER_QOS_DEFAULT,    // QoS 
		    NULL,                          // Listener 
			DDS_STATUS_MASK_NONE);
	      if (data_writer == NULL) {
		    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create data writer.%s\n"), ""));
	      } else {

            this->custom_data_writer_ = DATAWRITER::narrow(data_writer);
            if (this->custom_data_writer_ == NULL) {
	          ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create custom data writer.%s\n"), ""));
			} else {
		      return (0); // DDS connection successfull
			}
		  }
		}
      }
    }
  }
  return (-1); 
}

//
// is_source is true for effector worker, ie is a publisher, not a subscriber
//
template <typename TYPESUPPORT, typename DATAWRITER, typename TYPE>
bool DIG_Effector_Worker_T <TYPESUPPORT,DATAWRITER,TYPE>::is_source(void)
{
  return (true);
}

//
// get_type_name for this worker
//
template <typename TYPESUPPORT, typename DATAWRITER, typename TYPE>
const char * DIG_Effector_Worker_T <TYPESUPPORT,DATAWRITER,TYPE>::get_type_name (void)
{
  return (typesupport_Type::get_type_name());
}

//
// get_topic_name for this worker
//
template <typename TYPESUPPORT, typename DATAWRITER, typename TYPE>
const char * DIG_Effector_Worker_T <TYPESUPPORT,DATAWRITER,TYPE>::get_topic_name (void)
{
  return (this->topic_name_.c_str());
}

//
// Perform effector send data 
//
template <typename TYPESUPPORT, typename DATAWRITER, typename TYPE>
int DIG_Effector_Worker_T <TYPESUPPORT,DATAWRITER,TYPE>::send_data (TYPE * data)
{
  // ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Effector_Worker_T::send_data %s\n"), ""));

    DDS_ReturnCode_t retcode;

    if (this->custom_data_writer_ == NULL) {
      ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("send_data failed.%s\n"), ""));
      return -1;
	} else {
      //write data to publish writer
	  retcode = this->custom_data_writer_->write(*data, DDS_HANDLE_NIL);
      if (retcode != DDS_RETCODE_OK) {
        ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("send_data failed.%s\n"), ""));
        return -1;
      }
	}
    return 0;
}

