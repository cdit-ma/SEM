// -*- C++ -*-

//=============================================================================
/**
 * @file       WE_RAM.h
 *
 * $Id: WE_RAM.h 3378 2015-09-09 05:08:44Z marianne.rieckmannn $
 *
 * @author      Marianne Rieckmann
 */
//=============================================================================

#ifndef _WE_RAM_H_
#define _WE_RAM_H_

#include "WE_RAM_export.h"
#include "ace/Thread_Mutex.h"
#include <list>

/**
 * @class WE_RAM
 *
 * Workload generator for memory operations
 */
class WE_RAM_Export WE_RAM 
{
public:
  /// Constructor.
  WE_RAM (void);

  /// Destructor.
  virtual ~WE_RAM (void);

  /// Perform memory allocation.
  virtual void allocate (double kilobytes);

  /// Perform memory deallocation.
  virtual void deallocate (double kilobytes);

  virtual long counter (void) const;

private:
  /// Type definition for the container of allocations.
  typedef std::list <char *> Memory_Allocations;

  /// Locking mechanism for protecting <memory_>.
  ACE_Thread_Mutex lock_;

  /// Collection of memory allocations.
  Memory_Allocations memory_;
};

#if defined (__CUTS_INLINE__)
#include "WE_RAM.inl"
#endif

#endif  // !defined _WE_RAM_H_
