// $Id$

#include "WE_RAM.h"
#include "ace/Guard_T.h"

#define CUTS_MEMORY_ALLOC_SIZE 1024

//
// WE_RAM
//
WE_RAM::WE_RAM (void)
{

}

//
// ~WE_RAM
//
WE_RAM::~WE_RAM (void)
{
  try
  {
    // delete all the remaining memory in the container
    Memory_Allocations::iterator iter;

    for ( iter = this->memory_.begin ();
      iter != this->memory_.end ();
      iter ++)
    {
      delete [] (*iter);
    }
  }
  catch (...)
  {

  }
}

//
// allocate
//
void WE_RAM::allocate (double kilobytes)
{
  try
  {
    ACE_GUARD (ACE_Thread_Mutex, guard, this->lock_);

	// although the complexity function is evaluated to a double, only use integer for allocating memory
	unsigned long long KB = (unsigned long long) kilobytes;
    
	while (KB -- > 0)
    {
      char * allocation = 0;
      ACE_NEW (allocation, char [CUTS_MEMORY_ALLOC_SIZE]);

      if (allocation != 0)
        this->memory_.push_back (allocation);
    }
  }
  catch (...)
  {

  }
}

//
// deallocate
//
void WE_RAM::deallocate (double kilobytes)
{
  try
  {
    ACE_GUARD (ACE_Thread_Mutex, guard, this->lock_);

	unsigned long long KB = (unsigned long long) kilobytes;

    // Make sure we are not trying to deallocate more memory
    // that what is currently allocated.
    if (KB > this->memory_.size ())
      KB = this->memory_.size ();

    char * memory = 0;

    while (KB -- > 0)
    {
      // get the next allocation on the <memory_> stack
      memory = this->memory_.front ();
      this->memory_.pop_front ();

      // delete the piece of
      delete [] memory;
    }
  }
  catch (...)
  {

  }
}

//
// counter
//
long WE_RAM::counter (void) const
{
  return this->memory_.size ();
}
