// -*- C++ -*-

//=============================================================================
/**
 * @file       WE_CPU_Impl.h
 *
 * $Id: WE_CPU_Impl.h 3379 2014-11-06 05:44:17Z marianne.rieckmann $
 *
 * @author      Marianne Rieckmann
 */
//=============================================================================

#ifndef _WE_CPU_IMPL_H_
#define _WE_CPU_IMPL_H_

#include "ace/RW_Thread_Mutex.h"

#include "WE_CPU_export.h"

/**
 * @class WE_CPU
 */
class WE_CPU_Impl
{
public:

  /// Default constructor.
  WE_CPU_Impl (void);

  /// Destructor.
  ~WE_CPU_Impl (void);

  /**
   * Start Workload Execution of cpu benchmark loops
   *
   * @param[in]     loops           Number or loops to execute of this benchmark
   */
  int IntOp ( double loops );
  int FloatOp ( double loops );
  int Whetstone ( double loops );
  int Dhrystone ( double loops );
  int MWIP (double loops);
  int DMIP ( double loops );
  
private:

  ACE_RW_Thread_Mutex lock_;
};

#endif  // !defined _WE_CPU_IMPL_H_
