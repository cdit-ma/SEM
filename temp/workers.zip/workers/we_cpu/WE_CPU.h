// -*- C++ -*-

//=============================================================================
/**
 * @file       WE_CPU.h
 *
 * $Id: WE_CPU.h 3378 2014-11-06 05:08:44Z marianne.rieckmannn $
 *
 * @author      Marianne Rieckmann
 */
//=============================================================================

#ifndef _WE_CPU_H_
#define _WE_CPU_H_

#include "WE_CPU_export.h"

// Forward decl.
class WE_CPU_Impl;

/**
 * @class WE_CPU
 */
class WE_CPU_Export WE_CPU
{
public:
  /// Default constructor.
  WE_CPU (void);

  /// Destructor.
  ~WE_CPU (void);

//  int processVarList ( char * argvarlist, const char * complexity);
  int IntOp ( double loops );
  int FloatOp ( double loops );
  int Whetstone ( double loops );
  int Dhrystone ( double loops );
  int MWIP ( double loops );
  int DMIP ( double loops );

private:
  WE_CPU_Impl * impl_;
};

#endif  // !defined _WE_CPU_H_
