// $Id: WE_CPU_Impl.cpp 3380 2014-11-06 19:58:59Z marianne.rieckmann $

#include "WE_CPU_Impl.h"

//#include "cuts/UUID.h"
//#include "cuts/utils/testing/svcs/server/testingC.h"
#include "ace/OS_NS_string.h"
#include "ace/OS_NS_sys_time.h"
#include "ace/OS_NS_unistd.h"
#include "ace/Log_Msg.h"
//#include "ace/RW_Thread_Mutex.h"
#include "ace/Guard_T.h"

#include <iostream>
#include <cmath>      // Math. functions needed for whets.cpp?

#include "intop.cpp"
#include "floatop.cpp"
#include "whets.cpp"
#include "dhry_1.cpp"

//
// WE_CPU_Impl
//
WE_CPU_Impl::
WE_CPU_Impl (void)
{
  char * args_str = "";
  int argc = 0;
  char ** argv;

  ACE_OS::string_to_argv (args_str, argc, argv);
}

//
// WE_CPU_Impl
//
WE_CPU_Impl::~WE_CPU_Impl (void)
{

}

//
// IntOp
//
int WE_CPU_Impl::
IntOp ( double loops)
{
  try
  {
	// This guard will ensure only one CPU Workload Execution is occurring at any given time
	//  i.e. for this worker in this component.
    ACE_READ_GUARD_RETURN (ACE_RW_Thread_Mutex, guard, this->lock_, -1);

    ACE_Time_Value tv = ACE_OS::gettimeofday ();
    //logmsg.timestamp.sec = static_cast < ::CORBA::ULong > (tv.sec ());
    //logmsg.timestamp.usec = tv.usec ();
    
	// Workload Execution.
	if (loops > 0)
	{
	  integerop workload;
	  workload.loop( (unsigned long long)loops );
	  //printf("IntOp running with %lld loops\n",(unsigned long long)loops);
    }
    return 0;
  }
  catch (...)
  {
    ACE_ERROR ((LM_ERROR,
                ACE_TEXT ("%T (%t) - %M - caught unknown exception (%N:%l)\n")));
  }

  return -1;
}

//
// FloatOp
//
int WE_CPU_Impl::
FloatOp ( double loops)
{
  try
  {
	// This guard will ensure only one CPU Workload Execution is occurring at any given time
	//  i.e. for this worker in this component.
    ACE_READ_GUARD_RETURN (ACE_RW_Thread_Mutex, guard, this->lock_, -1);

    ACE_Time_Value tv = ACE_OS::gettimeofday ();
    //logmsg.timestamp.sec = static_cast < ::CORBA::ULong > (tv.sec ());
    //logmsg.timestamp.usec = tv.usec ();
    
	// Workload Execution.
	if (loops > 0)
	{
	  floatop workload;
	  workload.loop( (unsigned long long)loops );
	  //printf("FloatOp running with %lld loops\n",(unsigned long long)loops);
    }
    return 0;
  }
  catch (...)
  {
    ACE_ERROR ((LM_ERROR,
                ACE_TEXT ("%T (%t) - %M - caught unknown exception (%N:%l)\n")));
  }

  return -1;
}

//
// Whetstone
//
int WE_CPU_Impl::
Whetstone (double loops)
{
  try
  {
	// This guard will ensure only one CPU Workload Execution is occurring at any given time
	//  i.e. for this worker in this component.
    ACE_READ_GUARD_RETURN (ACE_RW_Thread_Mutex, guard, this->lock_, -1);

    ACE_Time_Value tv = ACE_OS::gettimeofday ();
    //logmsg.timestamp.sec = static_cast < ::CORBA::ULong > (tv.sec ());
    //logmsg.timestamp.usec = tv.usec ();
    
	// Workload Execution.
	if (loops > 0)
	{
	  whetstone workload;
	  workload.loop((int)loops);
	  //printf("Whetstone running with %d loops\n",(int)loops);
    }
    return 0;
  }
  catch (...)
  {
    ACE_ERROR ((LM_ERROR,
                ACE_TEXT ("%T (%t) - %M - caught unknown exception (%N:%l)\n")));
  }

  return -1;
}

//
// Dhrystone
//
int WE_CPU_Impl::
Dhrystone (double loops)
{
  try
  {
	// This guard will ensure only one CPU Workload Execution is occurring at any given time
	//  i.e. for this worker in this component.
    ACE_READ_GUARD_RETURN (ACE_RW_Thread_Mutex, guard, this->lock_, -1);

    ACE_Time_Value tv = ACE_OS::gettimeofday ();
    //logmsg.timestamp.sec = static_cast < ::CORBA::ULong > (tv.sec ());
    //logmsg.timestamp.usec = tv.usec ();
    
	// Workload Execution.
	if (loops > 0)
	{
	  dhrystone workload;
	  workload.loop((int)loops);
	  //printf("Dhrystone running with %d loops\n",(int)loops);
	}
    return 0;
  }
  catch (...)
  {
    ACE_ERROR ((LM_ERROR,
                ACE_TEXT ("%T (%t) - %M - caught unknown exception (%N:%l)\n")));
  }

  return -1;
}

//
// Whetstone MIP
//
int WE_CPU_Impl::
MWIP (double loops)
{
  try
  {
	// This guard will ensure only one CPU Workload Execution is occurring at any given time
	//  i.e. for this worker in this component.
    ACE_READ_GUARD_RETURN (ACE_RW_Thread_Mutex, guard, this->lock_, -1);

    ACE_Time_Value tv = ACE_OS::gettimeofday ();
    //logmsg.timestamp.sec = static_cast < ::CORBA::ULong > (tv.sec ());
    //logmsg.timestamp.usec = tv.usec ();
    
	// Workload Execution.
	if (loops > 0)
	{
	  whetstone workload;
	  workload.mwip((int)loops, true);
	  //printf("MWIP running with %d loops\n",(int)loops);
    }
    return 0;
  }
  catch (...)
  {
    ACE_ERROR ((LM_ERROR,
                ACE_TEXT ("%T (%t) - %M - caught unknown exception (%N:%l)\n")));
  }

  return -1;
}

//
// Dhrystone MIP
//
int WE_CPU_Impl::
DMIP (double loops)
{
  try
  {
	// This guard will ensure only one CPU Workload Execution is occurring at any given time
	//  i.e. for this worker in this component.
    ACE_READ_GUARD_RETURN (ACE_RW_Thread_Mutex, guard, this->lock_, -1);

    ACE_Time_Value tv = ACE_OS::gettimeofday ();
    //logmsg.timestamp.sec = static_cast < ::CORBA::ULong > (tv.sec ());
    //logmsg.timestamp.usec = tv.usec ();
    
	// Workload Execution.
	if (loops > 0)
	{
	  dhrystone workload;
	  // check for size of loops, ie for dhrystone selection must be integer not double
	  workload.dmip((int)loops, true);
	  //printf("DMIP running with %d dmip executions\n",(int)loops);
	}
    return 0;
  }
  catch (...)
  {
    ACE_ERROR ((LM_ERROR,
                ACE_TEXT ("%T (%t) - %M - caught unknown exception (%N:%l)\n")));
  }

  return -1;
}
