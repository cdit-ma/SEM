// $Id: WE_CPU.cpp 3378 2014-11-06 05:08:44Z marianne.rieckmann $

#include "WE_CPU.h"
#include "WE_CPU_Impl.h"
#include "ace/Guard_T.h"
#include "ace/CORBA_macros.h"
#include <sstream>
#include <iostream>

//
// WE_CPU
//
WE_CPU::WE_CPU (void)
: impl_ (0)
{
  ACE_NEW_THROW_EX (this->impl_,
                    WE_CPU_Impl (),
                    ACE_bad_alloc ());
}

//
// WE_CPU
//
WE_CPU::~WE_CPU (void)
{
  if (0 != this->impl_)
  {
    delete this->impl_;
    this->impl_ = 0;
  }
}

//
// Workload Execution 
//
int WE_CPU::IntOp ( double loop )
{

  // Assumes string resolves to an integer
  return this->impl_->IntOp ( loop );
}

//
// Workload Execution 
//
int WE_CPU::FloatOp ( double loop )
{
  // Assumes string resolves to an integer
  return this->impl_->FloatOp ( loop );
}


//
// Workload Execution 
//
int WE_CPU::Whetstone ( double loop )
{
  // Assumes string resolves to an integer
  return this->impl_->Whetstone ( loop );
}

//
// Workload Execution 
//
int WE_CPU::Dhrystone ( double loop )
{
  // Assumes string resolves to an integer
  return this->impl_->Dhrystone ( loop );
}

//
// Workload Execution 
//
int WE_CPU::MWIP ( double loop )
{
  // Assumes string resolves to an integer
  return this->impl_->MWIP ( loop );
}

//
// Workload Execution 
//
int WE_CPU::DMIP ( double loop )
{
  // Assumes string resolves to an integer
  return this->impl_->DMIP ( loop );
}
