// $Id: Synthetic_Worker_Subscriber.cpp 3467 2012-12-03 11:00:00Z marianne.rieckmann $

#include "Synthetic_Worker_T.h"
#include "Synthetic_Worker_Subscriber_T.h"
#include "ace/Log_Msg.h"

/* 
 * This method gets called back by DDS when one or more data samples have been received.
 */
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
void DIG_Synthetic_Worker_Subscriber_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::on_data_available(DDSDataReader *reader) {
  typedef TYPESUPPORT typesupport_type;
  typedef DATAREADER datareader_type;
  typedef TYPE synthetic_data_type;

  datareader_type * synthetic_reader = NULL;
  synthetic_data_type * sample = NULL;
  DDS_SampleInfo        info;
  DDS_ReturnCode_t      retcode;

  // Perform a safe type-cast from a generic data reader into a specific synthetic reader
  synthetic_reader = datareader_type::narrow(reader);
  if (synthetic_reader == NULL) {
    /* In this specific case, this will never fail */
    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DDSStringDataReader::narrow failed.%s\n"), ""));
    return;
  }
    
  /* Loop until there are messages available in the queue */
  sample = typesupport_type::create_data();
  for(;;) {
    retcode = synthetic_reader->read_next_sample( *sample, info);

    if (retcode == DDS_RETCODE_NO_DATA) {
      /* No more samples */
      break;

    } else if (retcode != DDS_RETCODE_OK) {
      ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to read data from data reader, error %s\n"), ""));
      return;
    }

    if (info.valid_data) {
      // Valid (this isn't just a lifecycle sample): allocate it
	  (this->worker_)->allocate(sample);
    }
  }
  typesupport_type::delete_data(sample);
}

