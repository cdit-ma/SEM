// SyntheticEngine.cpp : Defines the entry point for the console application.
//

#include "SE_DDSMessageInterface.h"
using namespace std;

// SE_ScenarioMessage constructor 
SE_ScenarioMessage::SE_ScenarioMessage() {
    ::ScenarioMessage * data = 0;
}
void SE_ScenarioMessage::setDDSMessage(void* ddsPtr) {
    this->data = (::ScenarioMessage*)(ddsPtr);
}
void * SE_ScenarioMessage::getDDSMessage(void) {
    return (this->data);
}
unsigned long long SE_ScenarioMessage::getTime(void) {
    return (this->data->eventElapseTime);
}


// Test data with ::sensor *
SE_sensor::SE_sensor() {
      ::sensor * data = 0;
}
void SE_sensor::setDDSMessage(void* ddsPtr) {
    this->data = (::sensor*)(ddsPtr);
}
void * SE_sensor::getDDSMessage(void) {
    return (this->data);
}
unsigned long long SE_sensor::getTime(void) {
    return (this->data->time);
}


