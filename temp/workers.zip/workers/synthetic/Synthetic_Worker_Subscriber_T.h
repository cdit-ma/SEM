// -*- C++ -*-

//=============================================================================
/**
 * @file    Synthetic_Worker_Subscriber.h
 *
 * $Id: Synthetic_Worker_Subscriber.h 3467 2012-12-03 11:00:00Z marianne.rieckmann $
 *
 * This file contains the DDS subscriber used by the synthetic worker in the CUTS 
 * runtime. 
 *
 * @author            Marianne Rieckmann <marianne.rieckmann@adelaide.edu.au>
 */
//=============================================================================

#ifndef _DIG_SYNTHETIC_WORKER_SUBSCRIBER_T_H_
#define _DIG_SYNTHETIC_WORKER_SUBSCRIBER_T_H_

#include <ndds/ndds_cpp.h>

// forward declarations
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
class DIG_Synthetic_Worker_T;

//using namespace std;

// The listener of events and data from the middleware 
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
class DIG_Synthetic_Worker_Subscriber_T : 
	public DDSDataReaderListener 
{
  public:
    void on_data_available(DDSDataReader *reader);

	/// worker that this subscriber belongs to.
  DIG_Synthetic_Worker_T <COMPONENT, TYPESUPPORT,DATAREADER,DATAWRITER,TYPE> * worker_;

};

#include "Synthetic_Worker_Subscriber_T.cpp"

#endif  // !defined _DIG_SYNTHETIC_WORKER_SUBSCRIBER_T_H_
