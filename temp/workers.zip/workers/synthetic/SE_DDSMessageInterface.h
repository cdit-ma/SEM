/**
 * @file    SE_DDSMessageInterface.h
 *
 * $Id: SE_DDSMessageInterface.h 3467 2013-07-15 11:00:00Z marianne.rieckmann $
 *
 * @author Marianne Rieckmann <marianne.rieckmann@adelaide.edu.au>
 */
//=============================================================================
#ifndef _SE_DDSMESSAGEINTERFACE_H_
#define _SE_DDSMESSAGEINTERFACE_H_

#pragma once

// Use Abstract class for dynamic allocation and polymorphism (ie interface)
//   to save pointers to unknown DDSMessage types in the priorety queue vector
class SE_DDSMessageInterface {
  public:
	virtual ~SE_DDSMessageInterface() = 0;
    virtual void setDDSMessage(void*) = 0;
    virtual void* getDDSMessage(void) = 0;
    virtual unsigned long long getTime(void) = 0;
};
SE_DDSMessageInterface::~SE_DDSMessageInterface() {}

// Structure to use to contain Data pointer in vector for priorety queue
struct SE_DDSMessageContainer{ 
  unsigned long long time;     
  std::string exchangeDataType;
  std::string exchangeTopicName;
  SE_DDSMessageInterface * ddsInterface;
};

// Compare different DDS Messages based on the time 
class compareDDSMessage{
public:
	bool operator() (SE_DDSMessageContainer& m1, SE_DDSMessageContainer& m2){
		if (m1.time > m2.time)
			return true;
		return false;
	}
};


// Data messages  ( since this is runtime allocation, need to generate derived classes for all data types ?
//                         or can the template code be generated within each sensor/effector worker ? )

//#include "SEMDataTypes.h"
//#include "SEMDataTypesSupport.h"
//#include "SEMDataTypes_publisher.h"

// Test with ::sensor *
//template <typename TYPE>
//class SE_sensor : public SE_DDSMessageInterface {
//  public:
//    ::sensor * data;
//    SE_sensor();
//    ~SE_sensor(void);
//    void setDDSMessage(void* ddsPtr);
//    void * getDDSMessage(void);
//    unsigned long long getTime(void);
//};

// SE_ControlMessage constructor 
//template <typename TYPE> SE_sensor<TYPE>::SE_sensor() {
//    TYPE * data = NULL;
//}
// SE_ControlMessage destructor
//template <typename TYPE> SE_sensor<TYPE>::~SE_sensor(void) {
//}
// SE_ControlMessage setter function 
//template <typename TYPE> void SE_sensor<TYPE>::setDDSMessage(void* ddsPtr) {
//    this->data = (TYPE *)(ddsPtr);
//}
// SE_ControlMessage getter function 
//template <typename TYPE> void * SE_sensor<TYPE>::getDDSMessage(void) {
//    return (this->data);
//}
// SE_ControlMessage get time value from data structure 
//template <typename TYPE> unsigned long long SE_sensor<TYPE>::getTime(void) {
//    return (this->data->sendTime);  //??
//}

#endif  // !defined _SE_DDSMESSAGEINTERFACE_H_

