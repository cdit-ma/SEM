// -*- C++ -*-

//=============================================================================
/**
 * @file    Synthetic_Worker_T.h
 *
 * $Id: Synthetic_Worker_T.h 3467 2013-07-15 11:00:00Z marianne.rieckmann $
 *
 * @author Marianne Rieckmann <marianne.rieckmann@adelaide.edu.au>
 */
//=============================================================================

#ifndef _DIG_SYNTHETIC_WORKER_T_H_
#define _DIG_SYNTHETIC_WORKER_T_H_

#include "cuts/Worker.h"
#include "Synthetic_Worker_Subscriber_T.h"
#include "SE_DIGWorkerInterface.h"
#include "SE_DDSMessageInterface.h"
#include "SE_Admin_Thread_T.h"
#include "ace/Thread_Mutex.h"
#include <list>
#include <vector>
#include <queue>

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif  // ACE_LACKS_PRAGMA_ONCE

#define _DIG_SYNTHETIC_WORKER_MAX_ALLOC_SIZE 10
#define _DIG_SYNTHETIC_WORKER_SINGLE_ALLOC 1

/// forward declaration

// Control messages
template <typename TYPE>
class SE_ControlMessage : public SE_DDSMessageInterface {
  private:
	TYPE * data;
  public:
    SE_ControlMessage();
    ~SE_ControlMessage(void);
    void setDDSMessage(void* ddsPtr);
    void * getDDSMessage(void);
    unsigned long long getTime(void);
};

// Structure to use in capabilities vector, used to interface between SE and component workers
// The structure will contain either a source or a destination named address associated with 
// an exchangeDataType and exchangeTopicName.
// It is assumed that the combination of type and topic is unique system wide, due to DDS layered messaging
struct SE_Capability { 
  SE_DIGWorkerInterface * workerInterface;

  std::string exchangeDataType;
  std::string exchangeTopicName;

  bool isSource;

  std::string ModelName;
  std::string ComponentName;
  std::string WorkerName;
};

// Find Capability in vector by exchangeDataType name
class SE_Capability_Match_Type {
private:
	const std::string exchangeDataType_;
public:
	SE_Capability_Match_Type(const std::string & type_name) : exchangeDataType_(type_name) {}
	bool operator()(const SE_Capability &worker) const {
		return (worker.exchangeDataType == exchangeDataType_);
	}
};

// Find Capability in vector by Model and Component and Worker name
class SE_Capability_Match_Worker {
private:
	const std::string ModelName_;
	const std::string ComponentName_;
	const std::string WorkerName_;
public:
	SE_Capability_Match_Worker(const std::string & model_name, const std::string & component_name, const std::string & worker_name) 
		                       : ModelName_(model_name), ComponentName_(component_name), WorkerName_(worker_name) {}
	bool operator()(const SE_Capability &worker) const {
		return ((worker.ModelName == ModelName_) && (worker.ComponentName == ComponentName_) && worker.WorkerName == WorkerName_);
	}
};

/**
 * @class DIG_Synthetic_Worker_T
 *
 * Workload generator for Synthetic operations
 */
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
class DIG_Synthetic_Worker_T : 
  public CUTS_Worker
{
public:
  /// Type definition for the interface to the Workers.
  typedef SE_DIGWorkerInterface Worker_Type;

  /// Type definition for the TypeSupport type
  typedef TYPESUPPORT typesupport_Type;

  /// Type definition for the DataReader type
  typedef DATAREADER datareader_Type;

    /// Type definition for the DataWriter type
  typedef DATAWRITER datawriter_Type;
  
  /// Type definition for the synthetic control type
  typedef TYPE control_Type;
  
  /// Constructor.
  DIG_Synthetic_Worker_T (void);

  /// Destructor.
  virtual ~DIG_Synthetic_Worker_T (void);

  /* Connect to Synthetic environment, 
   * @param[in]       model_name        This instance name for the model.
   * @param[in]       component_name    This instance name for the component.
   */
  int connect (const char * control_topic_name, const char * model_name, const char * component_name);

  /// Initialise each sensor and effector worker liked to this synthetic worker. This method will 
  /// set the target worker and member function that is to be called to switch the sensor worker topic. 
  void add_worker (SE_DIGWorkerInterface * worker, const char * worker_name);

  /// Disconnect from Sythetic environment
  int disconnect (void);

  /// Allocate synthetic control data to management vectors and queues 
  virtual void allocate (control_Type * data);

  /// Deallocate all memory from saved synthetic control  
  virtual void deallocate (void);

  /// get data from allocated list of synthetic control messages
  virtual void get_data (control_Type * data);

  /// send data acknowledge from 
  virtual int send_data (control_Type * data);

  /// Type definition for the container of synthetic control messages received.
  typedef std::priority_queue<SE_DDSMessageContainer, std::vector<SE_DDSMessageContainer>, compareDDSMessage> Synthetic_Allocations;

  /// Collection of synthetic control messages
  Synthetic_Allocations synthetic_pq_;

  /// Type definition for the container of capabilities.
  typedef std::vector<SE_Capability> Capability_Allocations;
  typedef Capability_Allocations::iterator Capability_Iterator;

  /// Collection of capability allocations.
  Capability_Allocations capabilities_;

  /// Administration thread is a periodic timer that will poll the priorety queue
  SE_Admin_Thread_T<DIG_Synthetic_Worker_T> admin_thread_;

  /// Callback for Admin_Thread, actioned when message in queue is overdue
  virtual void admin_thread_action (void);

private:
  /// Locking mechanism for protecting <synthetic_pq_>.
  ACE_Thread_Mutex synthetic_lock_;

  /// Locking mechanism for protecting <capabilities_>.
  ACE_Thread_Mutex capability_lock_;

  /// This Synthetic worker is associated to a model name and component name
  std::string                   model_name_;
  std::string                   component_name_;
  std::string                   control_topic_name_;

  /// DDS subscriber variables
  DDSDomainParticipant *        participant_;
  DDSTopic *                    topic_;
  DDSDataReader *               data_reader_;
  datawriter_Type *             custom_data_writer_;

  DIG_Synthetic_Worker_Subscriber_T <COMPONENT, TYPESUPPORT, DATAREADER, DATAWRITER, TYPE>  listener_;

};

#include "Synthetic_Worker_T.cpp"

#endif  // !defined _DIG_SYNTHETIC_WORKER_T_H_
