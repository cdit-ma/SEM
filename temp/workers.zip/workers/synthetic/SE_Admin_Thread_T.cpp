// $Id: SE_Admin_Thread_T.cpp 3467 2013-07-15 11:00:00Z marianne.rieckmann $

#include "SE_Admin_Thread_T.h"

//
// SE_Admin_Thread_T
//
template <typename SYNTHETICWORKER>
SE_Admin_Thread_T<SYNTHETICWORKER>::SE_Admin_Thread_T (void)
: syntheticworker_ (0),
  method_ (0), 
  timer_(-1),
  hertz_(1)
{
}

//
// ~SE_Admin_Thread_T
//
template <typename SYNTHETICWORKER>
SE_Admin_Thread_T<SYNTHETICWORKER>::~SE_Admin_Thread_T (void)
{
  this->deactivate ();
}

//
// activate
//
template <typename SYNTHETICWORKER>
int SE_Admin_Thread_T<SYNTHETICWORKER>::activate (void)
{
  // Activate the timer queue.
  int retval = this->timer_queue_.activate ();

  if (retval != 0)
    ACE_ERROR_RETURN ((LM_ERROR,
                       ACE_TEXT ("%T (%t) - %M - failed to activate timer priorety queue\n")),
                       -1);
  return 0;
}

//
// cancel_timeout
//
template <typename SYNTHETICWORKER>
void SE_Admin_Thread_T<SYNTHETICWORKER>::cancel_timeout (void)
{
  if (this->timer_ == -1)
    return;

  this->timer_queue_.cancel (this->timer_);
  this->timer_ = -1;
}

//
// deactivate
//
template <typename SYNTHETICWORKER>
int SE_Admin_Thread_T<SYNTHETICWORKER>::deactivate (void)
{
  // Cancel the current timeout.
  this->cancel_timeout ();

  // Deactivate the timer queue and wait for its thread(s) to return.
  this->timer_queue_.deactivate ();
  this->timer_queue_.wait ();

  return 0;
}

template <typename SYNTHETICWORKER>
void SE_Admin_Thread_T<SYNTHETICWORKER>::init (SyntheticWorker_Type * syntheticworker, Method_Pointer method)
{
  this->syntheticworker_ = syntheticworker;
  this->method_ = method;
}

// Schedule the first timeout and pass a pointer to the priorety queue to be polled
template <typename SYNTHETICWORKER>
int SE_Admin_Thread_T<SYNTHETICWORKER>::schedule_timeout ( double hertz, const void * pq )
{
//  ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("schedule_timeout hertz: %f (Hz) \n"), this->hertz_));
  setHertz(hertz);
  
  // Break the number into integer/fraction part, so we can print the int64 values as floats.
  double inverse = (1.0 / this->hertz_);
  double ipart = 0.0;
  double fpart = modf (inverse, &ipart);
  fpart *= ACE_ONE_SECOND_IN_USECS;
  printf("SE_Admin_Thread_T::schedule_timeout interval: %.0f (s) %.0f (us) \n", ipart, fpart );

  // find interval from given hertz (1/s)
  ACE_Time_Value interval;
  interval.set (inverse);
//  ACE_Time_Value delta;
//  delta.set ( static_cast <time_t> (ipart), static_cast <suseconds_t> (fpart));

  ACE_Time_Value first_time;
  first_time.set(inverse);//sec, micro); 

  // add current time to first_time to find the first time period
  first_time += ACE_OS::gettimeofday();

  // Schedule the arrival of the next event and all subsequent events at interval spacings.
  this->timer_ = this->timer_queue_.schedule (this, pq, first_time, interval);
  return this->timer_ != -1 ? 0 : -1;
}

//
// Setter function for hertz
//
template <typename SYNTHETICWORKER>
void SE_Admin_Thread_T<SYNTHETICWORKER>::setHertz (double hertz)
{
  this->hertz_ = hertz;
}

//
// Getter function for hertz
//
template <typename SYNTHETICWORKER>
double SE_Admin_Thread_T<SYNTHETICWORKER>::getHertz (void) const
{
  return this->hertz_;
}

//
// handle_timeout
//
template <typename SYNTHETICWORKER>
int SE_Admin_Thread_T<SYNTHETICWORKER>::handle_timeout (const ACE_Time_Value & curr_time, const void * pq)
{
    // Now, let's handle the timeout event.
    PriorityQueueType * pq_ptr = (PriorityQueueType *)pq;
    
	// Make sure we are not trying to get_data that is not currently allocated.
	if (pq_ptr->size() > 0) {                        //  (!pq_ptr->empty()) { ?
      //printf("Priority Queue Length: %d \n", pq_ptr->size() );

      // Watch the queue, interested in the top item only
	  SE_DDSMessageContainer ddsC = pq_ptr->top(); 
   
      // Time in DDS message may have come from chrono, but cannot use chrono as CUTS build with vs9
	  ACE_Time_Value time_now = ACE_OS::gettimeofday();
	  ACE_UINT64 time_now_ms = time_now.get_msec();

	  // Assume that time is in milliseconds and comparable to the system clock
	  if (time_now_ms > ddsC.time) {
        // callback to parent function... 
        if (this->syntheticworker_ != 0 && this->method_ != 0)
        {
          // Make upcall to the synthetic worker.
          (this->syntheticworker_->*this->method_) ();
        }
        else
        {
          if (this->syntheticworker_ == 0)
            ACE_ERROR ((LM_ERROR,
                  "%T (%t) - %M - target synthetic worker not set in admin thread"));
          else
            ACE_ERROR ((LM_ERROR,
                  "%T (%t) - %M - target method not set in admin thread"));
        }
	  }
	}

  return (0);
}




