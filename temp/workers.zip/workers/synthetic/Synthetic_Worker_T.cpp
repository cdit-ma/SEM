// $Id: Synthetic_Worker_T.cpp 3467 2012-11-29 11:00:00Z marianne.rieckmann $

#include "Synthetic_Worker_T.h"
#include "ace/Guard_T.h"
#include "ace/Log_Msg.h"

// SE_ControlMessage constructor 
template <typename TYPE>
SE_ControlMessage<TYPE>::SE_ControlMessage() {
    TYPE * data = NULL;
}
// SE_ControlMessage destructor
template <typename TYPE>
SE_ControlMessage<TYPE>::~SE_ControlMessage(void) {
}
// SE_ControlMessage setter function 
template <typename TYPE>
void SE_ControlMessage<TYPE>::setDDSMessage(void* ddsPtr) {
    this->data = (TYPE *)(ddsPtr);
}
// SE_ControlMessage getter function 
template <typename TYPE>
void * SE_ControlMessage<TYPE>::getDDSMessage(void) {
    return (this->data);
}
// SE_ControlMessage get time value from data structure 
template <typename TYPE>
unsigned long long SE_ControlMessage<TYPE>::getTime(void) {
    return (this->data->scenarioStartTime + this->data->eventElapseTime);
}

//
// DIG_Synthetic_Worker_T
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::DIG_Synthetic_Worker_T (void)
{
  this->participant_ = NULL;
  this->topic_ = NULL;
  this->data_reader_ = NULL;
  this->custom_data_writer_ = NULL;
  this->listener_.worker_ = this;

  this->control_topic_name_ = "SyntheticEnvironment";
  this->model_name_ = "";
  this->component_name_ = "";
}

//
// ~DIG_Synthetic_Worker
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::~DIG_Synthetic_Worker_T (void)
{
	// dealocate memory used by this worker
	deallocate();
}

//
// Connect to Synthetic environment
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
int DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::connect (const char * control_topic_name, const char * model_name, const char * component_name)
{
  ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Synthetic_Worker_T::connect %s %s %s\n"), control_topic_name, model_name, component_name));

  /// Subscribe to Synthetic environment DDS admin layer
  DDS_ReturnCode_t retcode;
  const char * type_name = typesupport_Type::get_type_name();
  DDSDataWriter *  data_writer;

  this->control_topic_name_ = control_topic_name;
  this->model_name_ = model_name;
  this->component_name_ = component_name;

  // Create the domain participant on domain ID 10  
  // !!! Use single participant for this SyntheticWorker Admin layer !!!
  // !!! may need to change QoS for more participants !!!
  this->participant_ = DDSDomainParticipantFactory::get_instance()->create_participant(
    10,                             // Domain ID
    DDS_PARTICIPANT_QOS_DEFAULT,    // QoS 
    NULL,                           // Listener 
    DDS_STATUS_MASK_NONE);
  if (this->participant_ == NULL) {
    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create domain participant.%s\n"), ""));
  } else {

	retcode = typesupport_Type::register_type(this->participant_, type_name);
	if (retcode != DDS_RETCODE_OK) {
	    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to register type with domain participant.%s\n"), ""));
	} else {
		// Create the topic for Synthetic Worker 
		this->topic_ = this->participant_->create_topic(
			this->control_topic_name_.c_str(),     // Topic name
			type_name,                             // Type name 
			DDS_TOPIC_QOS_DEFAULT,                 // Topic QoS 
			NULL,                                  // Listener  
			DDS_STATUS_MASK_NONE);
		if (this->topic_ == NULL) {
			ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create topic.%s\n"), ""));
		} else {

          // Create the data writer using the implicit publisher for this participant 
		  data_writer = this->participant_->create_datawriter(
			this->topic_,
	        DDS_DATAWRITER_QOS_DEFAULT,    // QoS 
		    NULL,                          // Listener 
			DDS_STATUS_MASK_NONE);
	      if (data_writer == NULL) {
		    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create data writer.%s\n"), ""));
	      } else {

            this->custom_data_writer_ = DATAWRITER::narrow(data_writer);
            if (this->custom_data_writer_ == NULL) {
	          ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create custom data writer.%s\n"), ""));
			} else {

    	      // Create the data reader using the default publisher 
	    	  this->data_reader_ = this->participant_->create_datareader(
		    	this->topic_,
	            DDS_DATAREADER_QOS_DEFAULT,    // QoS 
		        &(this->listener_),            // Listener 
			    DDS_DATA_AVAILABLE_STATUS);
	          if (this->data_reader_ == NULL) {
		        ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create data reader.%s\n"), ""));
	          } else {

			    // Activate the administration thread periodic timer
			    this->admin_thread_.activate();
		    	// Initialize callback function
			    this->admin_thread_.init(this, &DIG_Synthetic_Worker_T<COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::admin_thread_action);
			    // Set interval for admin_thread_ and set pointer to poll the priorety queue to every 0.1ms
                this->admin_thread_.schedule_timeout( 10000.0, &this->synthetic_pq_);

		        return (0); // DDS connection successfull
		      }
			}
		  }
       }
     }
  }
  return (-1); 
}

//
// init
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
void DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::add_worker (SE_DIGWorkerInterface * worker, const char * worker_name)
{
  /// Add worker details to capability and add to vector
  SE_Capability capability;
  capability.workerInterface = worker;
  capability.isSource = worker->is_source(); 
  capability.exchangeDataType = worker->get_type_name();
  capability.exchangeTopicName = worker->get_topic_name();
  capability.ModelName = this->model_name_.c_str();
  capability.ComponentName = this->component_name_.c_str();
  capability.WorkerName = worker_name;
  
  try
  {
    /// Locking mechanism for protecting <capabilities_>.
    ACE_GUARD (ACE_Thread_Mutex, guard, this->capability_lock_);

    // find ???UNIQUE??? exchangeDataType capability in this component
    //  ( but may not be unique, may have more than one worker with same type in one component ???)
    Capability_Iterator it = std::find_if(capabilities_.begin(),
                                          capabilities_.end(),
                                          SE_Capability_Match_Type(capability.exchangeDataType));
    // not found so add this capability to the list.
    if (it == capabilities_.end()) {
       capabilities_.push_back(capability);
    }

    // find ???UNIQUE??? exchangeDataType capability in this component
    //  ( but may not be unique, may have more than one worker with same type in one component ???)
    Capability_Iterator thisCapability = std::find_if(capabilities_.begin(),
                                          capabilities_.end(),
                                          SE_Capability_Match_Type(capability.exchangeDataType));
    if ( thisCapability != capabilities_.end() ) {
      /// Publish Synthetic worker on Synthetic environment DDS Admin layer
      control_Type * ack = typesupport_Type::create_data();
      ack->sentTime = ACE_OS::gettimeofday ().get_msec ();;
      ack->scenarioStartTime = 0;
      ack->scenarioEndElapseTime = 0;
      ack->eventElapseTime = 0;
      ack->eventPeriod = 0;
      ack->controlType = 2; // acknowledge (SEM to Synthetic Env)
      ack->exchangeDataType = thisCapability->exchangeDataType.c_str();  // @key
      ack->exchangeTopicName = thisCapability->exchangeTopicName.c_str();  // @key
	  // Scenario identifiers
      ack->scenarioName = "";
      ack->organisationName = "";
      ack->unitName = "";  
      ack->eventName = "";
	  // SEM identifiers 
      ack->modelName = thisCapability->ModelName.c_str() ;
      ack->componentName = thisCapability->ComponentName.c_str() ;
      ack->workerName = thisCapability->WorkerName.c_str() ; 
      this->send_data (ack);
	  // if (retcode != DDS_RETCODE_OK) after this command, we could print an error message?
      DDS_ReturnCode_t retcode = typesupport_Type::delete_data(ack);
	}
  }
  catch (...)
  {

  }
}

//
// Disconnect from Sythetic environment
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
int DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::disconnect (void)
{
  DDS_ReturnCode_t              retcode = DDS_RETCODE_OK;

  ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Synthetic_Worker_T::disconnect %s\n"), ""));

  if (this->participant_ != NULL) {
    retcode = this->participant_->delete_contained_entities();
    if (retcode != DDS_RETCODE_OK) {
	    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Deletion failed.%s\n"), ""));
    }
    retcode = DDSDomainParticipantFactory::get_instance()->delete_participant(this->participant_);
    if (retcode != DDS_RETCODE_OK) {
	    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Deletion failed.%s\n"), ""));
    }
  }

  // Deactivate the administration thread periodic timer
  this->admin_thread_.deactivate();

  if (retcode == DDS_RETCODE_OK)
    return (0);
  else 
    return (-1);
}

//
// allocate memory for synthetic control messages and assign value ready for use in the component
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
void DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::allocate (TYPE * data)
{
   //ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Synthetic_Worker_T::allocate %s == %s && %s == %s\n"), 
   //  data->modelName, this->model_name_.c_str(), data->componentName, this->component_name_.c_str()));

  /// Filter control messages and only action control for this model and/or component.
  if ( (!strcmp(data->modelName, this->model_name_.c_str()) && !strcmp(data->componentName, this->component_name_.c_str()) )
	   || (!strcmp(data->modelName, this->model_name_.c_str()) && !strcmp(data->componentName, "")) )
  {
    try
    {
      ACE_GUARD (ACE_Thread_Mutex, guard, this->synthetic_lock_);

      control_Type * allocation = typesupport_Type::create_data();
      if (allocation != NULL) {

        // copy message in sample to local copy within derived class of SE_DDSMessageInterface
        typesupport_Type::copy_data(allocation, data);
	    SE_DDSMessageInterface * ddsI = new SE_ControlMessage<control_Type>;  
	    ddsI->setDDSMessage(allocation);

        // create message container and set time value for priorety in the queue 
        SE_DDSMessageContainer ddsC;
        ddsC.time = ddsI->getTime();
        ddsC.exchangeDataType = allocation->exchangeDataType; //typesupport_Type::get_type_name();
		ddsC.exchangeTopicName = allocation->exchangeTopicName;
        ddsC.ddsInterface = ddsI;

        this->synthetic_pq_.push (ddsC);
      }
    }
    catch (...)
    {

    }
  }
}

//
// Perform synthetic control retreival and dealocate memory, get available message from list and remove
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
void DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::get_data (TYPE * data)
{
  // ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Synthetic_Worker_T::get_data %s\n"), ""));
  try
  {
    ACE_GUARD (ACE_Thread_Mutex, guard, this->synthetic_lock_);

    // Make sure we are not trying to get_data that is not currently allocated.
    if (this->synthetic_pq_.size () > 0) 
  	{
      // get the next allocation on the <synthetic_pq_> stack
	  SE_DDSMessageContainer ddsC = this->synthetic_pq_.top(); 
      SE_DDSMessageInterface * ddsI = ddsC.ddsInterface;
      control_Type * allocation = (control_Type *)(ddsI->getDDSMessage());
      typesupport_Type::copy_data(data, allocation);
 
      this->synthetic_pq_.pop(); 
      // delete the message
	  typesupport_Type::delete_data(allocation);
	  // delete the derived class from the interface ptr
	  delete ddsI;
    } 
  }
  catch (...)
  {

  }
}

//
// Perform effector send data 
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
int DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::send_data (TYPE * data)
{
  // ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Synthetic_Worker_T::send_data %s\n"), ""));

    DDS_ReturnCode_t retcode;

    if (this->custom_data_writer_ == NULL) {
      ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("send_data failed.%s\n"), ""));
      return -1;
	} else {
      //write data to publish writer
	  retcode = this->custom_data_writer_->write(*data, DDS_HANDLE_NIL);
      if (retcode != DDS_RETCODE_OK) {
        ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("send_data failed.%s\n"), ""));
        return -1;
      }
	}
    return 0;
}
//
// Callback for Admin_Thread, actioned when message in queue is overdue
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
void DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::admin_thread_action ()
{
  //printf("DIG_Synthetic_Worker_T::admin_thread_action prioretyqueue size: %d \n", synthetic_pq_.size() );
  /// Action the control message in timely fashion
  control_Type control_message;

  this->get_data( & control_message );

  if (control_message.controlType == 2) // do nothing for acknowledge message (SEM to Synthetic Env)
	  return;

  /// Check if any workers topic needs to switch to a new name as requested by Synthetic environment DDS admin layer
  // find unique??? exchangeDataType capability in this component 
  //      or may need to find by Model/Component/Worker name ???
  std::string data_type = (const char*)control_message.exchangeDataType;
  Capability_Iterator capability = std::find_if( capabilities_.begin(),
                                                 capabilities_.end(),
												 SE_Capability_Match_Type(data_type.c_str()) );
  if ( capability != capabilities_.end() ) {

    // if control topic name is different to current capability topic name, switch topics.
    std::string topic_name = (const char*)control_message.exchangeTopicName;
//    printf(" capabliity semTopicName: %s \n", capability->exchangeTopicName.c_str() );
//    printf(" worker topic_name: %s \n", capability->workerInterface->get_topic_name() );
//    printf(" control topic: %s \n", topic_name.c_str() );
	if ( strcmp( topic_name.c_str(), capability->workerInterface->get_topic_name() ) ) 
    {
	  capability->workerInterface->switch_topic( topic_name.c_str() ); 
	  // Save the new topic_name in the capability data structure
      capability->exchangeTopicName = topic_name.c_str();

	  /// Publish change on Synthetic environment DDS Admin layer
      control_Type * ack = typesupport_Type::create_data();
      ack->sentTime = ACE_OS::gettimeofday ().get_msec ();;
      ack->scenarioStartTime = 0;
      ack->scenarioEndElapseTime = 0;
      ack->eventElapseTime = 0;
      ack->eventPeriod = 0;
      ack->controlType = 2; // acknowledge (SEM to Synthetic Env)
      ack->exchangeDataType = capability->exchangeDataType.c_str();  // @key
      ack->exchangeTopicName = capability->exchangeTopicName.c_str();  // @key
  	// Scenario identifiers
      ack->scenarioName = "";
      ack->organisationName = "";
      ack->unitName = "";  
      ack->eventName = "";
	  // SEM identifiers 
      ack->modelName = capability->ModelName.c_str() ;
      ack->componentName = capability->ComponentName.c_str() ;
      ack->workerName = capability->WorkerName.c_str() ; 
      this->send_data (ack);
	  // if (retcode != DDS_RETCODE_OK) after this command, we could print an error message?
      DDS_ReturnCode_t retcode = typesupport_Type::delete_data(ack);
    }
  }
}

//
// deallocate all memory allocated to synthetic
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
void DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::deallocate (void)
{
  try
  {
    ACE_GUARD (ACE_Thread_Mutex, guard, this->synthetic_lock_);

    // Deallocate the memory allocated to the synthetic
    size_t allocsize = this->synthetic_pq_.size ();

	SE_DDSMessageContainer ddsC;
	SE_DDSMessageInterface * ddsI = NULL;
    control_Type * allocation = NULL; 

    while (allocsize-- > 0)
    {
      // get the next allocation on the <synthetic_pq_> stack
	  ddsC = this->synthetic_pq_.top(); 
      ddsI = ddsC.ddsInterface;
      allocation = (control_Type *)(ddsI->getDDSMessage());

	  this->synthetic_pq_.pop(); 

	  // delete the message
	  typesupport_Type::delete_data(allocation);
	  // delete the derived class from the interface ptr 
	  delete ddsI;
    }
  }
  catch (...)
  {

  }
}


/*
//
// handle_switch_topic if Admin DDS layer needs to switch topic?
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename DATAWRITER, typename TYPE>
int DIG_Synthetic_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,DATAWRITER,TYPE>::handle_switch_topic (void)
{
  if (this->component_ != 0 && this->method_ != 0)
  {
    // Make upcall to the component.
    (this->component_->*this->method_) ();
  }
// Missing callback is not an error, as it may not be defined in the model for this worker.
//  else
//  {
//    if (this->component_ == 0)
//      ACE_ERROR ((LM_ERROR,
//                  "%T (%t) - %M - target component not set in synthetic worker"));
//    else
//      ACE_ERROR ((LM_ERROR,
//                  "%T (%t) - %M - target method not set in synthetic worker"));
//  }

  return 0;
}
*/
