// -*- C++ -*-

//=============================================================================
/**
 * @file        SE_Admin_Thread_T.h
 *
 * $Id: SE_Admin_Thread_T.h 3467 2013-07-15 11:00:00Z marianne.rieckmann $
 *
 * @author Marianne Rieckmann <marianne.rieckmann@adelaide.edu.au>
 */
//=============================================================================

#ifndef _SE_ADMIN_THREAD_T_H_
#define _SE_ADMIN_THREAD_T_H_

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif  // ACE_LACKS_PRAGMA_ONCE

#include "cuts/Active_Object.h"
#include "ace/Timer_Heap.h"
#include "ace/Timer_Queue_Adapters.h"
#include <vector>
#include <queue>

/**
 * @class SE_Admin_Thread_T
 *
 * Base class for administration thread.
 */
template <typename SYNTHETICWORKER>
class SE_Admin_Thread_T :
  public ACE_Event_Handler //, public CUTS_Active_Object
{
public:
  /// Type definition for the hosting synthetic worker type.
  typedef SYNTHETICWORKER SyntheticWorker_Type;

  /// Type definition for pointer to member funcntion.
  typedef void (SYNTHETICWORKER::* Method_Pointer) (void);

  /// Type definition for the container of syntethic data messages received.
  typedef std::priority_queue<SE_DDSMessageContainer, std::vector<SE_DDSMessageContainer>, compareDDSMessage> PriorityQueueType;

  /// Default constructor.
  SE_Admin_Thread_T (void);

  /// Destructor.
  virtual ~SE_Admin_Thread_T (void);

  /// Activate the admin thread.
  virtual int activate (void);

  /// Deactivate the admin thread.
  virtual int deactivate (void);

  /// Schedule the timer to action at a frequency of herts, and action pq data
  int schedule_timeout ( double hertz, const void * pq );

  /// Setter method for hertz
  void setHertz (double hertz);

  /// Getter method for hertz
  double getHertz (void) const;

  // Initialise the timer queue and set the callback to the parent class
  void init (SyntheticWorker_Type * syntheticworker, Method_Pointer method);

  // Handle timeout thread
  int handle_timeout (const ACE_Time_Value & timeout, const void * pq);

protected:

  /// Timer ID for the scheduled time.
  long timer_;

  /// Hold the timeout value.
  double hertz_;

private:

  /// Cancel timeout on deactivate
  void cancel_timeout (void);

  /// The timer queue for the periodic task.
  ACE_Thread_Timer_Queue_Adapter <ACE_Timer_Heap> timer_queue_;

  /// Pointer the parent synthetic worker of the stored method.
  SyntheticWorker_Type * syntheticworker_;

  /// Pointer to the <SYNTHETICWORKER> member function to handle queued message.
  Method_Pointer method_;

};

#include "SE_Admin_Thread_T.cpp"

#endif  // !defined _SE_ADMIN_THREAD_T_H_
