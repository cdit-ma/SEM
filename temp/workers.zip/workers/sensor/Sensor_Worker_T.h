// -*- C++ -*-

//=============================================================================
/**
 * @file    Sensor_Worker_T.h
 *
 * $Id: Sensor_Worker_T.h 3467 2012-12-21 11:00:00Z marianne.rieckmann $
 *
 * This file contains the sensor worker generic implementation
 *
 * @author Marianne Rieckmann <marianne.rieckmann@adelaide.edu.au>
 */
//=============================================================================

#ifndef _DIG_SENSOR_WORKER_T_H_
#define _DIG_SENSOR_WORKER_T_H_

#include "cuts/Worker.h"
#include "Sensor_Worker_Subscriber_T.h"
#include "SE_DIGWorkerInterface.h"
#include "ace/Thread_Mutex.h"
#include <list>

#define _DIG_SENSOR_WORKER_MAX_ALLOC_SIZE 10
#define _DIG_SENSOR_WORKER_SINGLE_ALLOC 1

#if !defined (ACE_LACKS_PRAGMA_ONCE)
# pragma once
#endif  // ACE_LACKS_PRAGMA_ONCE

/// forward declaration

/**
 * @class DIG_Sensor_Worker_T
 *
 * Workload generator for Sensor operations
 */
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
class DIG_Sensor_Worker_T : 
  public CUTS_Worker, public SE_DIGWorkerInterface
{
public:
  /// Type definition for the hosting component type.
  typedef COMPONENT Component_Type;

  /// Type definition for pointer to member funcntion.
  typedef void (COMPONENT::* Method_Pointer) (void);

  /// Type definition for the TypeSupport type
  typedef TYPESUPPORT typesupport_Type;

  /// Type definition for the DataReader type
  typedef DATAREADER datareader_Type;
  
  /// Type definition for the sensor data type
  typedef TYPE sensordata_Type;
  
  /// Constructor.
  DIG_Sensor_Worker_T (void);

  /// Destructor.
  virtual ~DIG_Sensor_Worker_T (void);

  /// Initialise sensor worker before activating the sensor. This method will 
  /// set the target component and the member function that is to be called 
  /// when the sensor has received data.
  void init (Component_Type * component, Method_Pointer method);

  /* Connect to Synthetic environment, 
   * @param[in]       topictype        Topic and type information for sensor data DDS.
   */
  int connect (const char * topic_name);

  /// Disconnect from Sythetic environment
  int disconnect (void);

  // Switch Topic for the Synthetic environment
  int switch_topic (const char * topic_name);
  bool is_source(void);
  const char * get_type_name(void);
  const char * get_topic_name(void);

  /// Allocate memory to save sensor data 
  virtual void allocate (sensordata_Type * data);

  // deallocate excess memory allocated to sensor
  virtual void deallocate (size_t allocsize);

  /// Deallocate all memory from saved sensor data 
  virtual void deallocate (void);

  /// Return sensor_ size()
  virtual long counter (void) const;

  /// Return true if sensor_ size() is greater than zero
  virtual bool data_ready (void) const;

  /// get available data from list and remove
  virtual void get_data (sensordata_Type * data);

  virtual void handle_data_received (void);

  /// Type definition for the container of allocations.
  typedef std::list <sensordata_Type *> Sensor_Allocations;

  /// Collection of sensor allocations.
  Sensor_Allocations sensor_;

protected:
  /// Handler for data received event
  virtual int handle_data_received_i (void);
//  virtual int handle_data_received_i (void) = 0;


private:
   /// Pointer the parent component of the stored method.
  Component_Type * component_;

  /// Pointer to the <COMPONENT> member function assigned to this trigger event.
  Method_Pointer method_;

  /// Locking mechanism for protecting <sensor_>.
  ACE_Thread_Mutex lock_;

  /// DDS subscriber variables
  DDSDomainParticipant *        participant_;
  DDSTopic *                    topic_;
  DDSDataReader *               data_reader_;
  std::string                   topic_name_;

  // should the listener be an auto_ptr to ensure end of life disconnect???
  // std::auto_ptr <DIG_Sensor_Worker_Subscriber_T <COMPONENT, TYPESUPPORT,DATAREADER,TYPE> > listener;
  DIG_Sensor_Worker_Subscriber_T <COMPONENT, TYPESUPPORT,DATAREADER,TYPE>  listener_;

};

#if defined (__CUTS_INLINE__)
#include "Sensor_Worker_T.inl"
#endif

#include "Sensor_Worker_T.cpp"

#endif  // !defined _DIG_SENSOR_WORKER_T_H_
