// $Id: Sensor_Worker_T.cpp 3467 2012-11-29 11:00:00Z marianne.rieckmann $

#if !defined (__CUTS_INLINE__)
#include "Sensor_Worker_T.inl"
#endif

//
// DIG_Sensor_Worker_T
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::DIG_Sensor_Worker_T (void)
: component_ (0),
  method_ (0)
{
  this->participant_ = NULL;
  this->topic_ = NULL;
  this->data_reader_ = NULL;
  this->topic_name_ = "";
  this->listener_.worker_ = this;
}

//
// ~DIG_Sensor_Worker
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::~DIG_Sensor_Worker_T (void)
{
  deallocate();
}

//
// Connect to Synthetic environment
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
int DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::connect (const char * topic_name)
{
  DDS_ReturnCode_t retcode;
  const char * type_name = TYPESUPPORT::get_type_name();
  this->topic_name_ = topic_name;

  ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Sensor_Worker_T::connect %s\n"), this->topic_name_.c_str()));

  // Create the domain participant on domain ID 11 
  this->participant_ = DDSDomainParticipantFactory::get_instance()->create_participant(
    11,                             // Domain ID
    DDS_PARTICIPANT_QOS_DEFAULT,    // QoS 
    NULL,                           // Listener 
    DDS_STATUS_MASK_NONE);
  if (this->participant_ == NULL) {
    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create domain participant.%s\n"), ""));
  } else {
	retcode = TYPESUPPORT::register_type(this->participant_, type_name);
	if (retcode != DDS_RETCODE_OK) {
	    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to register type with domain participant.%s\n"), ""));
	} else {
		// Create the topic "Sensor Worker" 
		this->topic_ = this->participant_->create_topic(
			this->topic_name_.c_str(),             // Topic name
			type_name,                             // Type name 
			DDS_TOPIC_QOS_DEFAULT,                 // Topic QoS 
			NULL,                                  // Listener  
			DDS_STATUS_MASK_NONE);
		if (this->topic_ == NULL) {
			ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create topic.%s\n"), ""));
		} else {
	      // Create the data writer using the default publisher 
		  this->data_reader_ = this->participant_->create_datareader(
			this->topic_,
	        DDS_DATAREADER_QOS_DEFAULT,    // QoS 
		    &(this->listener_),             // Listener 
			DDS_DATA_AVAILABLE_STATUS);
	      if (this->data_reader_ == NULL) {
		    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create data reader.%s\n"), ""));
	      } else {
		    return (0); // DDS connection successfull
		  }
       }
     }
  }
  return (-1); 
}

//
// Disconnect from Sythetic environment
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
int DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::disconnect (void)
{
  DDS_ReturnCode_t              retcode = DDS_RETCODE_OK;

  ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Sensor_Worker_T::disconnect %s\n"), ""));

  if (this->participant_ != NULL) {
    retcode = this->participant_->delete_contained_entities();
    if (retcode != DDS_RETCODE_OK) {
	    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Deletion failed.%s\n"), ""));
    }
    retcode = DDSDomainParticipantFactory::get_instance()->delete_participant(this->participant_);
    if (retcode != DDS_RETCODE_OK) {
	    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Deletion failed.%s\n"), ""));
    }
  }
  if (retcode == DDS_RETCODE_OK)
    return (0);
  else 
    return (-1);
}

//
// Switch Topic for the Synthetic environment
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
int DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::switch_topic (const char * topic_name)
{
  DDS_ReturnCode_t retcode;
  const char * type_name = TYPESUPPORT::get_type_name();
  this->topic_name_ = topic_name;

  ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Sensor_Worker_T::switch_topic %s\n"), this->topic_name_.c_str() ));

  // Assume and check that the domain participant exists
  if (this->participant_ != NULL) {

    // Delete the previous datareader and topic from this participant.
	retcode = this->participant_->delete_datareader(this->data_reader_);
	if (retcode != DDS_RETCODE_OK) {
	    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Deletion of datareader failed.%s\n"), ""));
    } else { 
		retcode = this->participant_->delete_topic(this->topic_);
		if (retcode != DDS_RETCODE_OK) {
	   		ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Deletion of topic failed.%s\n"), ""));
    	} else { 
			// Create the new topic for Sensor Worker  
			this->topic_ = this->participant_->create_topic(
				this->topic_name_.c_str(),             // Topic name
				type_name,                             // Type name 
				DDS_TOPIC_QOS_DEFAULT,                 // Topic QoS 
				NULL,                                  // Listener  
				DDS_STATUS_MASK_NONE);
			if (this->topic_ == NULL) {
				ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create topic.%s\n"), ""));
			} else {
    			// Create the data writer using the default publisher 
				this->data_reader_ = this->participant_->create_datareader(
					this->topic_,
    		    	DDS_DATAREADER_QOS_DEFAULT,    // QoS 
			    	&(this->listener_),             // Listener 
					DDS_DATA_AVAILABLE_STATUS);
    			if (this->data_reader_ == NULL) {
					ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to create data reader.%s\n"), ""));
    		  	} else {
			    	return (0); // DDS connection successfull
				}
			}
		}
    }
  }
  return (-1); 
}

//
// is_source is false for sensor worker, ie not a publisher, is a subscriber
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
bool DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::is_source(void)
{
  return (false);
}

//
// get_type_name for this worker
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
const char * DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::get_type_name (void)
{
  return (TYPESUPPORT::get_type_name());
}

//
// get_topic_name for this worker
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
const char * DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::get_topic_name (void)
{
  return (this->topic_name_.c_str());
}

//
// allocate memory on a char list for sensor data and assign data value ready for use in the component
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
void DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::allocate (TYPE * data)
{
  // ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Sensor_Worker_T::allocate %s\n"), data));
  try
  {
    ACE_GUARD (ACE_Thread_Mutex, guard, this->lock_);

    sensordata_Type * allocation = typesupport_Type::create_data();
    if (allocation != NULL) {
      typesupport_Type::copy_data(allocation, data);
      this->sensor_.push_back (allocation);

      // In the case where memory is being allocated but no get_data() is retrieving the data
      //   if the amount of memory allocated to this sensor is excessive, ie over a maximum size
      //     the oldest sensor readings should be dumped but retain the most recent readings
      size_t allocsize = this->sensor_.size ();
      if ( allocsize >= _DIG_SENSOR_WORKER_MAX_ALLOC_SIZE )
      {
        // deallocate one sample to remain under the maximum allowed samples
        this->deallocate(_DIG_SENSOR_WORKER_SINGLE_ALLOC);
      }
	  }
  }
  catch (...)
  {

  }
}

//
// deallocate excess memory allocated to sensor
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
void DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::deallocate (size_t allocsize)
{
  try
  {
    ACE_GUARD (ACE_Thread_Mutex, guard, this->lock_);

    // Make sure we are not trying to deallocate more memory
    // that what is currently allocated.
    if (allocsize > this->sensor_.size ())
      allocsize = this->sensor_.size ();

    sensordata_Type * allocation = NULL;

    while (allocsize-- > 0)
    {
      // get the next allocation on the <sensor_> stack
      allocation = this->sensor_.front ();
      this->sensor_.pop_front ();

      // delete the piece of
      typesupport_Type::delete_data(allocation);
    }
  }
  catch (...)
  {

  }
}

//
// deallocate all memory allocated to sensor
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
void DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::deallocate (void)
{
  try
  {
    ACE_GUARD (ACE_Thread_Mutex, guard, this->lock_);

    // Deallocate the memory allocated to the sensor
    size_t allocsize = this->sensor_.size ();

    sensordata_Type * allocation = 0;

    while (allocsize-- > 0)
    {
      // get the next allocation on the <sensor_> stack
      allocation = this->sensor_.front ();
      this->sensor_.pop_front ();

      // delete the piece of
      typesupport_Type::delete_data(allocation);
    }
  }
  catch (...)
  {

  }
}

//
// Perform sensor data retreival and dealocate memory, get available data from list and remove
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
void DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::get_data (TYPE * data)
{
  // ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DIG_Sensor_Worker_T::get_data %s\n"), ""));
  try
  {
    ACE_GUARD (ACE_Thread_Mutex, guard, this->lock_);

    // Make sure we are not trying to deallocate more memory that is currently allocated.
    if (this->sensor_.size () > 0) 
  	{
      // get the next allocation on the <sensor_> stack
      sensordata_Type * allocation = this->sensor_.front ();
      typesupport_Type::copy_data(data, allocation);
 
      this->sensor_.pop_front ();
      // delete the piece of
      typesupport_Type::delete_data(allocation);
    } 
  }
  catch (...)
  {

  }
}

//
// handle_data_received callback to component and method using _i()
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
void DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::handle_data_received ( void )
{
  this->handle_data_received_i();
}


//
// handle_timeout
//
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
int DIG_Sensor_Worker_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::handle_data_received_i (void)
{
  if (this->component_ != 0 && this->method_ != 0)
  {
    // Make upcall to the component.
    (this->component_->*this->method_) ();
  }
// Missing callback is not an error, as it may not be defined in the model for this worker.
//  else
//  {
//    if (this->component_ == 0)
//      ACE_ERROR ((LM_ERROR,
//                  "%T (%t) - %M - target component not set in sensor worker"));
//    else
//      ACE_ERROR ((LM_ERROR,
//                  "%T (%t) - %M - target method not set in sensor worker"));
//  }

  return 0;
}
