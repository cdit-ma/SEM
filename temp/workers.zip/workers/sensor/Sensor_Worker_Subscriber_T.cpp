// $Id: Sensor_Worker_Subscriber.cpp 3467 2012-12-03 11:00:00Z marianne.rieckmann $

#include "Sensor_Worker_T.h"
#include "Sensor_Worker_Subscriber_T.h"
#include "ace/Log_Msg.h"

/* This method gets called back by DDS when one or more data samples have been
 * received.
 */
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
void DIG_Sensor_Worker_Subscriber_T <COMPONENT,TYPESUPPORT,DATAREADER,TYPE>::on_data_available(DDSDataReader *reader) {

  datareader_Type *     sensor_reader = NULL;
  sensordata_Type *     sample = NULL;
  DDS_SampleInfo        info;
  DDS_ReturnCode_t      retcode;

  // Perform a safe type-cast from a generic data reader into a specific sensor reader
  sensor_reader = datareader_Type::narrow(reader);
  if (sensor_reader == NULL) {
    /* In this specific case, this will never fail */
    ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("DDSStringDataReader::narrow failed.%s\n"), ""));
    return;
  }
    
  /* Loop until there are messages available in the queue */
  sample = typesupport_Type::create_data();
  for(;;) {
    retcode = sensor_reader->read_next_sample( *sample, info);
    if (retcode == DDS_RETCODE_NO_DATA) {
      /* No more samples */
      break;
    } else if (retcode != DDS_RETCODE_OK) {
      ACE_DEBUG ((LM_DEBUG, ACE_TEXT ("Unable to read data from data reader, error %s\n"), ""));
      return;
    }
    if (info.valid_data) {
      // Valid (this isn't just a lifecycle sample): allocate it
		  (this->worker_)->allocate(sample);

      (this->worker_)->handle_data_received();
    }
  }
  typesupport_Type::delete_data(sample);
}

