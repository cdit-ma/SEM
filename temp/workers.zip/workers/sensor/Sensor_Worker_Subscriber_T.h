// -*- C++ -*-

//=============================================================================
/**
 * @file    Sensor_Worker_Subscriber.h
 *
 * $Id: Sensor_Worker_Subscriber.h 3467 2012-12-03 11:00:00Z marianne.rieckmann $
 *
 * This file contains the DDS subscriber used by the sensor worker in the CUTS 
 * runtime. 
 *
 * @author            Marianne Rieckmann <marianne.rieckmann@adelaide.edu.au>
 */
//=============================================================================

#ifndef _DIG_SENSOR_WORKER_SUBSCRIBER_T_H_
#define _DIG_SENSOR_WORKER_SUBSCRIBER_T_H_

#include <ndds/ndds_cpp.h>

// forward declarations
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
class DIG_Sensor_Worker_T;

//using namespace std;

// The listener of events and data from the middleware 
template <typename COMPONENT, typename TYPESUPPORT, typename DATAREADER, typename TYPE>
class DIG_Sensor_Worker_Subscriber_T : 
	public DDSDataReaderListener 
{
  public:
    /// Type definition for the TypeSupport type
    typedef TYPESUPPORT typesupport_Type;

    /// Type definition for the DataReader type
    typedef DATAREADER datareader_Type;
  
    /// Type definition for the sensor data type
    typedef TYPE sensordata_Type;

    void on_data_available(DDSDataReader *reader);

	/// worker that this subscriber belongs to.
  DIG_Sensor_Worker_T <COMPONENT, TYPESUPPORT,DATAREADER,TYPE> * worker_;

};

#include "Sensor_Worker_Subscriber_T.cpp"

#endif  // !defined _DIG_SENSOR_WORKER_SUBSCRIBER_T_H_
