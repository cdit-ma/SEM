// -*- C++ -*-

//=============================================================================
/**
 * @file       WE_UTE.h
 *
 * $Id: WE_UTE.h 3378 2015-09-09 05:08:44Z marianne.rieckmannn $
 *
 * @author      Marianne Rieckmann
 */
//=============================================================================

#ifndef _WE_UTE_H_
#define _WE_UTE_H_

#include "WE_UTE_export.h"

// Forward decl.
class WE_UTE_Impl;

/**
 * @class WE_UTE
 */
class WE_UTE_Export WE_UTE
{
public:
  /// Default constructor.
  WE_UTE (void);

  /// Destructor.
  ~WE_UTE (void);

  int processVarList ( char * argvarlist, const char * complexity);
  double evaluateComplexity ( const char * complexity, ...);
  char * timeOfDay ( char * timeString);
//  ACE_Time_Value timeOfDay ( ACE_Time_Value timeStruct);
  double timeOfDay ( double timeValue);

private:
  WE_UTE_Impl * impl_;
};

#endif  // !defined _WE_UTE_H_
