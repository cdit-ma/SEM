// $Id: WE_UTE.cpp 3378 2015-09-09 05:08:44Z marianne.rieckmann $

#include "WE_UTE.h"
#include "WE_UTE_Impl.h"
#include "ace/Guard_T.h"
#include "ace/CORBA_macros.h"
#include <sstream>
#include <iostream>
#include "atmsp.h"

//
// WE_UTE
//
WE_UTE::WE_UTE (void)
: impl_ (0)
{
  ACE_NEW_THROW_EX (this->impl_,
                    WE_UTE_Impl (),
                    ACE_bad_alloc ());
}

//
// WE_UTE
//
WE_UTE::~WE_UTE (void)
{
  if (0 != this->impl_)
  {
    delete this->impl_;
    this->impl_ = 0;
  }
}

//
// complexity variables required for atmsp
//
int WE_UTE::processVarList ( char * argvarlist, const char * complexity)
{
  //printf("complexity %s \n", complexity);
  char * cptr;
  char varlist[50];	
  char mathchar[] = "()-+*/^0123456789";
  char mathfunc[23][6] = {"abs", "acos", "asin", "atan", "atan2", "cos", "cosh", 
						"exp", "log", "log10", "sin", "sinh", "sqrt", "tan", "tanh",
						"floor", "round", "min", "max", "sig", "log2", "$e", "$pi" };
  //remove all math functions from complexity algorithm
  strcpy(varlist, complexity);
  for (unsigned int i = 0; i < 23; ++i)
  {
    cptr = varlist;
    while ((cptr=strstr(cptr,mathfunc[i])) != NULL)
	  memmove(cptr, cptr+strlen(mathfunc[i]), strlen(cptr+strlen(mathfunc[i]))+1);
  }
  //remove all math characters from varlist
  for (unsigned int i = 0; i < strlen(mathchar); ++i)
  {
    cptr = varlist;
    while ((cptr=strchr(cptr ,mathchar[i])) != NULL)
	  memmove(cptr, cptr+1, strlen(cptr+1)+1);
  }
  //remove duplicate variables
  char * prev = varlist;
  while ((*prev) != '\0') 
  {
	cptr = prev + 1;
    while ((cptr=strchr(cptr,(*prev))) != NULL)
      memmove(cptr, cptr+1, strlen(cptr+1)+1);
    prev += 1;
  }
  // now have list of unique parameters
  unsigned int varlistLength = strlen(varlist);
  // comma delimit the parameters
  cptr = varlist;
  cptr++;
  while ((*cptr) != '\0')
  {
    memmove(cptr+1, cptr, strlen(cptr)+1);
    memcpy(cptr, ",", 1);
    cptr+=2;
  }
  //printf("varlist %s \n", varlist);
  strcpy(argvarlist, varlist);
  return varlistLength;
}

//
// Workload Execution evaluateComplexity Utility function
//
double WE_UTE::evaluateComplexity ( const char * complexity, ...)
{
  // Initialize the variable arguments list.
  va_list args;
  va_start (args, complexity);

  char varlist[50];	
  unsigned int varlistLength = processVarList(varlist, complexity);

  // Parse the complexity string.
  ATMSP<double> parser;
  ATMSB<double> byteCode;

  // Parse your expression with a variables list AFTER constant declarations
  // Both the expression and the variables list are case sensitive and may contain blanks
  size_t err = parser.parse(byteCode, complexity, varlist);
  if ( err  )
    std::cout << "Parsing failed with: " << parser.errMessage(err) << std::endl;
  
  // Set variable values BEFORE final bytecode execution. Same principle for more variables
  for (unsigned int i=0; i < varlistLength; ++i)
  {
	byteCode.var[i] = va_arg( args, double );   // x is 1st in the above variables list, so it has index 0
  }

  // End the variable arguments.
  va_end (args);
  
  // And execute the bytecode with the variable/constant values set above
  double result = byteCode.run();

  // In need to check float errors like division by zero or negative roots e.g?
  if ( byteCode.fltErr )
    std::cerr << "Faced a NaN/inf error" <<  std::endl;

  return ( result );
}

//
// Workload Execution timeOfDay Utility function
//
char * timeOfDay ( char * timeString)
{ 
  return timeString;
}

//
// Workload Execution timeOfDay Utility function 
//
//ACE_Time_Value timeOfDay ( ACE_Time_Value timeStruct)
//{ 
//  return timeStruct;
//}

//
// Workload Execution timeOfDay Utility function 
//
double timeOfDay ( double timeValue)
{ 
  return timeValue;
}
