// $Id: WE_UTE_Impl.cpp 3380 2015-09-09 19:58:59Z marianne.rieckmann $

#include "WE_UTE_Impl.h"

//#include "cuts/UUID.h"
//#include "cuts/utils/testing/svcs/server/testingC.h"
#include "ace/OS_NS_string.h"
#include "ace/OS_NS_sys_time.h"
#include "ace/OS_NS_unistd.h"
#include "ace/Log_Msg.h"
//#include "ace/RW_Thread_Mutex.h"
#include "ace/Guard_T.h"

#include <iostream>
#include <cmath>      // Math. functions needed for whets.cpp?

//
// WE_UTE_Impl
//
WE_UTE_Impl::
WE_UTE_Impl (void)
{
  char * args_str = "";
  int argc = 0;
  char ** argv;

  ACE_OS::string_to_argv (args_str, argc, argv);
}

//
// WE_UTE_Impl
//
WE_UTE_Impl::~WE_UTE_Impl (void)
{

}

//
// evaluateComplexity
//
char * WE_UTE_Impl::
timeOfDay ( char * timeString)
{
  try
  {
	// This guard will ensure only one Utility function call is occurring at any given time
	//  i.e. for this worker in this component.
	bool locked = false;
    ACE_GUARD_ACTION (ACE_RW_Thread_Mutex, guard, this->lock_, locked=false, locked=true);

	if (locked) 
	{
		strcpy(timeString, "n/a");
	}
	else
	{
		// Create timeStamp in seconds with six decimal places for usec precision
		ACE_Time_Value timeStamp = ACE_OS::gettimeofday(); 
		double timeStampNow = timeStamp.sec() + timeStamp.usec()*1e-6;
	
		// Create string representation of time 
		char timeStampSec[12]; sprintf(timeStampSec, "%d", timeStamp.sec() );
		char timeStampUsec[12]; sprintf(timeStampUsec, "%06ld", timeStamp.usec());
		char timeStampStr[24]; sprintf(timeStampStr, "%s.%s", timeStampSec, timeStampUsec);
    
		strcpy(timeString, timeStampStr);
	}
  }
  catch (...)
  {
    ACE_ERROR ((LM_ERROR,
                ACE_TEXT ("%T (%t) - %M - caught unknown exception (%N:%l)\n")));
  }

  return ( timeString );
}

