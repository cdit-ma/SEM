// -*- C++ -*-

//=============================================================================
/**
 * @file       WE_UTE_Impl.h
 *
 * $Id: WE_UTE_Impl.h 3379 2015-09-09 05:44:17Z marianne.rieckmann $
 *
 * @author      Marianne Rieckmann
 */
//=============================================================================

#ifndef _WE_UTE_IMPL_H_
#define _WE_UTE_IMPL_H_

#include "ace/RW_Thread_Mutex.h"

#include "WE_UTE_export.h"

/**
 * @class WE_UTE
 */
class WE_UTE_Impl
{
public:

  /// Default constructor.
  WE_UTE_Impl (void);

  /// Destructor.
  ~WE_UTE_Impl (void);

  /**
   * Start Utility functions for Workload Execution
   */
  double evaluateComplexity ( const char * complexity, ...);
  char * timeOfDay ( char * timeString);
//  ACE_Time_Value timeOfDay ( ACE_Time_Value timeStruct);
  double timeOfDay ( double timeValue);
  
private:

  ACE_RW_Thread_Mutex lock_;
};

#endif  // !defined _WE_UTE_IMPL_H_
