/**
 * @file    SE_DIGWorkerInterface.h
 *
 * $Id: SE_DIGWorkerInterface.h 3467 2013-07-15 11:00:00Z marianne.rieckmann $
 *
 * @author Marianne Rieckmann <marianne.rieckmann@adelaide.edu.au>
 */
//=============================================================================

#ifndef _SE_DIGWORKERINTERFACE_H_
#define _SE_DIGWORKERINTERFACE_H_

#pragma once

// Abstract class to interface to the Sensor worker switch_topic() function
class SE_DIGWorkerInterface {
  public:
	virtual ~SE_DIGWorkerInterface() = 0;
	virtual int switch_topic (const char * topic_name) = 0;
	virtual bool is_source(void) = 0;
	virtual const char * get_type_name(void) = 0;
	virtual const char * get_topic_name(void) = 0;
};

SE_DIGWorkerInterface::~SE_DIGWorkerInterface() {}

#endif  // !defined _SE_DIGWORKERINTERFACE_H_
